package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numero_1;
		System.out.println("Dime un numero: ");
		numero_1=sc.nextInt();
		int numero_2;
		System.out.println("Dime otro numero: ");
		numero_2=sc.nextInt();
		if (numero_1 % numero_2 == 0) {
			System.out.println("El segundo numero es multiplo del primero.");
		}else if (numero_2 % numero_1 == 0) {
			System.out.println("El primer numero es multiplo del segundo.");
		}else {
			System.out.println("Ninguno de los numeros es multiplo del otro.");
		}
		
	}

}
