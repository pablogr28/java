package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 int dia;
		 System.out.println("Dime que dia es:  ");
		 dia=sc.nextInt();
		 int mes;
		 System.out.println("Dime que mes es: ");
		 mes=sc.nextInt();
		 if ((mes == 12 && dia >= 21) || (mes == 1 && dia <= 19)) {
			 System.out.println("La temperatura a programar es 19 grados.");
	        } else if ((mes == 3 && dia >= 20) || (mes == 4 && dia <= 19)) {
	        	System.out.println("La temperatura a programar es 20 grados.");
	        } else if ((mes == 6 && dia >= 20) || (mes == 7 && dia <= 21)) {
	        	System.out.println("La temperatura a programar es 24 grados.");
	        } else if ((mes == 9 && dia >= 22) || (mes == 10 && dia <= 20)) {
	        	System.out.println("La temperatura a programar es 19 grados.");
	        } else {
	            System.out.println("Mes o dia invalido.");
	        }
	    }
	}
