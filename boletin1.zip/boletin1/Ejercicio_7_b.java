package main.java.boletin1;

public class Ejercicio_7_b {
	public static void main(String[] args) {
		for (int i = 100; i >= 0; i--) {
			System.out.println(i);
		}
	}

	public static void ejercicioB() {
		int i = 100;
		while(i >= 0) {
			System.out.println(i);
			i--;
		}
	}
	
	public static void ejercicioC() {
		   int i=100;
		   do {
		       System.out.println(i);
		       i--;
		   } while(i>=0);
		}

}
