package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_17 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce hasta que termino quieres ver de Fibonacci:");
        int fibonacci = scanner.nextInt();
        int numero1=0;
        int numero2=1;
        int numeroFinal=0;
        int i=1;
        do {
        	if (i==1 || i==2) {
        		numeroFinal=i;
        	}else {
        		numeroFinal=numero1+numero2;
        		numero1=numero2;
        		numero2=numeroFinal;
        	}
        	System.out.println(numeroFinal);
        	i++;
        }while(i<=fibonacci);
        
        System.out.println("Tu numero Fibonacci es: "+numeroFinal);
	}
}

