package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String diaSemana;
		System.out.println("Dime que dia de la semana quieres elegir: ");
		diaSemana=sc.next().toLowerCase();
		if (diaSemana.equals("lunes")) {
			System.out.println("Base de Datos.");
		} else if (diaSemana.equals("martes")) {
			System.out.println("Entorno de Desarrollo.");
		} else if (diaSemana.equals("miercoles")) {
			System.out.println("Base de Datos.");
		} else if (diaSemana.equals("jueves")) {
			System.out.println("Lenguaje de Marcas.");
		} else if (diaSemana.equals("viernes")) {
			System.out.println("Sistemas Informáticos.");
		} else {
			System.out.println("Día de la semana incorrecto.");
		}
	}
}
