package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_13 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		 float numeroMayor=0;
		 float numeroMenor=1000000000;
		 int i=1;
		 do {
			 System.out.println("Introduce un número:");
	         int numero = scanner.nextInt();
	         
	         if (numero>numeroMayor) {
	        	 numeroMayor=numero;
	        	 i++;
	         }else if(numero<numeroMenor){
	        	 numeroMenor=numero;
	        	 i++;
	         }else {
	        	 i++;
	         }
		 }while(i<=10);
		 System.out.println("El numero mayor es "+numeroMayor+" y el numero menor es "+numeroMenor);
	}
}
