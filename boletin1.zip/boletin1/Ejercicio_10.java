package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_10 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 int numero;
		 System.out.println("Dime un numero:  ");
		 numero=sc.nextInt();
		int suma100=0;
		int i=1;
		int sumatoria=numero+1;
		do {
			suma100+=numero+sumatoria;
			sumatoria++;
			 i++;
		}while(i<=100);
		System.out.println("La suma de los 100 siguientes números es "+suma100);
	}
}
