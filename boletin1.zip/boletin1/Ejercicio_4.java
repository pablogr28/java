package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_4 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 double notaPractica;
		 System.out.println("Dime tu nota Practica: ");
		 notaPractica=sc.nextDouble();
		 double notaProblemas;
		 System.out.println("Dime tu nota en Problemas: ");
		 notaProblemas=sc.nextDouble();
		 double notaTeorica;
		 System.out.println("Dime tu nota Teorica: ");
		 notaTeorica=sc.nextDouble();
		 if (notaPractica >= 0 && notaPractica <=10 && notaProblemas >= 0 && notaProblemas <=10 && notaTeorica >= 0 && notaTeorica <=10) {
			 System.out.println("Todas las notas estan correctas.");
		 } else {
			 System.out.println("Algunas de las notas no son correctas.");
		 }
			 
		 double notaFinal=(notaPractica*0.10)+(notaProblemas*0.50)+(notaTeorica*0.40);
		 if (notaFinal<5) {
			 System.out.println("Has suspendido. Tu nota es "+notaFinal);
		 }else if (notaFinal>5 && notaFinal<6) {
			 System.out.println("Tienes un suficiente. Tu nota es "+notaFinal);
		 }else if (notaFinal>6 && notaFinal<7) {
			 System.out.println("Tienes un Bien. Tu nota es "+notaFinal);
		 }else if (notaFinal>7 && notaFinal<9) {
			 System.out.println("Tienes un Notable. Tu nota es "+notaFinal);
		 }else if (notaFinal>9 && notaFinal<=10) {
			 System.out.println("Tienes un Sobresaliente. Tu nota es "+notaFinal);
		 }else {
			 System.out.println("Nota incorrecta.");
		 }
	}
}
