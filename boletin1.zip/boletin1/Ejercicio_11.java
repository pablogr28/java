package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_11{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean esNegativo=true;
        while (esNegativo) {
            System.out.println("Introduce un número:");
            int numero = scanner.nextInt();

            if (numero < 0) {
            	esNegativo=false;
                System.out.println("Número no válido. Por favor, introduce un número positivo o cero.");
            }

            int cuadrado = numero * numero;
            System.out.println("El cuadrado de " + numero + " es " + cuadrado + ".");
        }
    }
}
