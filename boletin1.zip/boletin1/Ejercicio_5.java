package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 double horaDia;
		 System.out.println("Dime que hora es: ");
		 horaDia=sc.nextDouble();
		 if (horaDia<=6.00 && horaDia <12.00) {
			 System.out.println("Buenos días.");
		 }else if (horaDia>=12.00 && horaDia<20.00) {
			 System.out.println("Buenas tardes.");
		 }else if (horaDia>=20.00 || horaDia<6.00) {
			 System.out.println("Buenas noches.");
		 }
	}
}
