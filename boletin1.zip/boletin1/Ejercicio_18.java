package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_18 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce cuanto mide tu radio:");
        int radio = scanner.nextInt();
        double area = Math.PI * Math.pow(radio, 2);
        System.out.println("El area de tu circunferencia es "+area);
        double longitud = longitudCircunferencia(radio);
	}
	
	public static double longitudCircunferencia(int radio) {
        double longitud = 2 * Math.PI * radio;
        System.out.println("La longitud de tu circunferencia es "+longitud);
        return longitud;
	}
}

