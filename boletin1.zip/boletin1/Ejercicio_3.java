package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_3 {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       char caracter;
       System.out.println("Selecciona un caracter cualquiera.");
       caracter = sc.next().charAt(0);
       if (Character.isLowerCase(caracter)) {
           System.out.println("Tu caracter es una letra minuscula.");
       } else if (Character.isUpperCase(caracter)) {
           System.out.println("Tu caracter es una letra mayuscula.");
       } else if (Character.isDigit(caracter)) {
           System.out.println("Tu caracter es un numero.");
       } else if (caracter == '.') {
           System.out.println("Tu caracter es un signo de puntuacion.");
       } else if (caracter == ' ') {
           System.out.println("Tu caracter es un espacio en blanco.");
       } else if (caracter == '(' || caracter == ')' || caracter == '{' || caracter == '}') {
           System.out.println("Tu caracter es un parentesis o llaves.");
       } else {
           System.out.println("Tu caracter es otro caracter.");
       }
   }
}
