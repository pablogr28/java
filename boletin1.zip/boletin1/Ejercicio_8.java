package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_8 {
	public static void main(String[] args) {
		int sumaFinal=0;
		int i=1;
		do {
			Scanner sc = new Scanner(System.in);
			 int numero;
			 System.out.println("Dime un numero:  ");
			 numero=sc.nextInt();
			 sumaFinal+=numero;
			 i++;
		} while (i<=15);
		
		System.out.println("La suma final de los 15 números son: "+sumaFinal);
	}
}

