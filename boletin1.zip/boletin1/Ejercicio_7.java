package main.java.boletin1;


public class Ejercicio_7 {
	public static void main(String[] args) {
		int i=1;
		do {
			System.out.println(i);
			i++;
		}while (i > 0 && i <= 100);
	    	  
	      
	}
}
