package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_9 {
	public static void main(String[] args) {
		int i=1;
		int contadorMultiplo=0;
		do {
			Scanner sc = new Scanner(System.in);
			 int numero;
			 System.out.println("Dime un numero:  ");
			 numero=sc.nextInt();
			 if (numero%3==0) {
				 contadorMultiplo+=1;
				 i++; 
			 }else {
				 i++;
			 }
			 
		}while(i<=5);
		
		System.out.println("Hay "+contadorMultiplo+" multiplos de 3");
	}
}