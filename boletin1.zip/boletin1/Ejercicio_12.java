package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_12 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        boolean esNegativo=true;
        int contadorNumeros=0;
        while (esNegativo) {
            System.out.println("Introduce un número:");
            int numero = scanner.nextInt();

            if (numero < 0) {
            	esNegativo=false;
                System.out.println("Número no válido. Por favor, introduce un número positivo o cero.");
            }
            
            contadorNumeros+=1;
        }
        System.out.println("Hay "+contadorNumeros+" números");
	}
}
