package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_14 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        boolean esNegativo=true;
        int contadorNumeros=0;
        int sumaNumerosImpares=0;
        int numerosImpares=0;
        int mayorPares=0;
        while (esNegativo) {
            System.out.println("Introduce un número:");
            int numero = scanner.nextInt();

            if (numero < 0) {
            	esNegativo=false;
                System.out.println("Número no válido. Por favor, introduce un número positivo o cero.");
            }else if (numero%3==0) {
            	sumaNumerosImpares+=numero;
            	numerosImpares+=1;
            }else if (numero%2==0) {
            	if (numero>mayorPares) {
            		mayorPares=numero;
            	}
            }
            
            contadorNumeros+=1;
        }
        float mediaImpares=sumaNumerosImpares/numerosImpares;
        System.out.println("Hay "+contadorNumeros+" números");
        System.out.println("La media de los números impares es "+mediaImpares);
        System.out.println("El mayor de los números pares es "+mayorPares);
	}
}
