package main.java.boletin1;
import java.util.Scanner;
public class Ejercicio_16 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int contadorPersonas=1;
		int sumaSalario=0;
		int contador1000=0;
		do {
			 System.out.println("Introduce tu salario:");
	         int salario = scanner.nextInt();
	         if (salario >=1000) {
	        	 contador1000+=1;
	        	 sumaSalario+=salario;
	         }else {
	        	 sumaSalario+=salario;
	         }
	         contadorPersonas++;
		}while(contadorPersonas<=10);
		
		System.out.println("La suma de todos los salario es: "+sumaSalario);
		System.out.println("Hay "+contador1000+" personas que cobran mas de 1000 euros.");
	}
}
